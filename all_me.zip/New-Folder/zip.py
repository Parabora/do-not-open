import zipfile
import sys

def crack_zip(zip_file, wordlist):
    try:

        with zipfile.ZipFile(zip_file) as zf:

            with open(wordlist, 'r', encoding='utf-8', errors='ignore') as f:

                for word in f:
                    password = word.strip()
                    try:

                        zf.extractall(pwd=password.encode('utf-8'))
                        print(f"\n[+] تم العثور على كلمة المرور: {password}")
                        return
                    except (RuntimeError, zipfile.BadZipFile, zipfile.LargeZipFile):

                        print(f"[-] تجربة كلمة المرور: {password} (فشل)")
                        continue
                    except Exception as e:

                        print(f"حدث خطأ غير متوقع: {e}")
                        return
    except FileNotFoundError:
        print("[-] ملف ZIP أو قائمة الكلمات غير موجودة.")
    except Exception as e:
        print(f"حدث خطأ: {e}")

if __name__ == "__main__":

    zip_file = input("أدخل اسم ملف ZIP: ")
    wordlist = input("أدخل مسار قائمة كلمات المرور (wordlist): ")


    print(f"\n[+] بدء عملية كسر كلمة المرور لملف: {zip_file}")
    crack_zip(zip_file, wordlist)
