import itertools
import pyfiglet


logo = pyfiglet.figlet_format("HICHAM", font="standard") 
print(logo)

characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_=+"

password_length = int(input("Enter the password length: "))
file_name = input("Enter the output file name (e.g., passwords.txt): ")

batch_size = 10_000_000

all_combinations = itertools.product(characters, repeat=password_length)

file_count = 1
current_count = 0
file = open(f"{file_name}_{file_count}.txt", "w")

for combination in all_combinations:
    password = "".join(combination)
    file.write(password + "\n")
    current_count += 1

    if current_count >= batch_size:
        file.close()
        print(f"Created file: {file_name}_{file_count}.txt")
        file_count += 1
        current_count = 0
        file = open(f"{file_name}_{file_count}.txt", "w")

file.close()
print("All files have been created.")
